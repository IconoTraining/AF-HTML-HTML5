function mostrar_mapa(){
    if (navigator.geolocation){
        navigator.geolocation.getCurrentPosition(mostrarLocalizacion, manejarError);
    } else {
        alert("Tu navegador no soporta geolocalizacion");
    }
}

function mostrarLocalizacion(posicion){
    var pos = new google.maps.LatLng(posicion.coords.latitude, posicion.coords.longitude);

    // Configuracion del mapa
    var opciones = {
        zoom: 12,
        mapTypeId: google.maps.MapTypeId.ROADMAP
    };

    // Crear el mapa
    var mapa = new google.maps.Map(document.getElementById("seccion_mapa"), opciones);

    // Centrar el mapa
    mapa.setCenter(pos);

}

function manejarError(error){
    alert(error);
}