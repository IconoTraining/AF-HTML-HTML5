function saludar(){
    alert("Hola que tal?");
}